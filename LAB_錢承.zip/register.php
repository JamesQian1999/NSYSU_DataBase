<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<form name="form" method="post" action="register_finish.php">
<center>
<h4 class="title toc-ignore">請輸入個人資料及密碼</h4>
帳號 <input type="text" name="id" /> <br>
密碼 <input type="password" name="pw" /> <br>
姓名 <input type="text" name="name" /> <br>
實驗室編號 <input type="text" name="lab" /> <br>
Email <input type="email" name="email" /> <br>
電話 <input type="text" name="telephone" /> <br><br>
<input type="submit" name="button" value="確定" style="height:50px; width:100px"/>
</center>
</form>