<!-- 設定網頁編碼為UTF-8 -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<form name="form" method="post" action="connect.php">
    <center>
    <br><br><h4 class="title toc-ignore">教室與設備借用系統</h4>
        帳號：<input type="text" name="id" /> <br>
        密碼：<input type="password" name="pw" /> <br>
        <br><input type="submit" name="button" value="登入" style="height:50px; width:100px"/>&nbsp;&nbsp;
        <a href="register.php">申請帳號</a>
    </center>
</form>
